function [x_sol,obj_sol,res_xy_track, res_x_track, num_iter] = ADMM_mem_QP(options)

     rho = options.rho;
     d = options.d;
     G = options.G;
     h = options.h;
     eps = options.eps;
     MaxIter = options.MaxIter;
     
     n = length(d); 
     l = size(G,1);
     
     x = zeros(n,1); y = x; mu = x;
     
     C = [ rho*eye(n), G.'; G, zeros(l,l) ];  
     [C_map, c_map] = linearMapMem(C);
     
     eig_value = eigs(C,1,'SM');
     if abs(eig_value) < 1e-10
          error('error in invertible C!');
     end
     
     Cinv = inv(C); C_mapinv = inv(C_map);
     
     for i = 1:MaxIter
         %%% x-step
         alpha = y - (1/rho)*( d + mu );
         c = [ rho*alpha; h ];
         c_map_ex = [c; c_map];
         %%% Cx = c; C_map x_ex = c_map
         x_ex = C_mapinv*c_map_ex;
         xnew = x_ex(1:n); 
         x_test = Cinv*c;
         if max(abs(xnew - x_test(1:n))) > 1e-3
             error('error in mem. mapping!');
         end
             
         %%% y-step
         beta = xnew + (1/rho)*(mu);
         
         if norm(beta(1:(end-1)),2) <= -beta(end)
             ynew = beta*0;
         elseif  norm(beta(1:(end-1)),2) <= beta(end)
             ynew = beta;
         else 
             ynew = (1/2)*( 1 + beta(end)/norm(beta(1:(end-1)),2) )*[ beta(1:(end-1));  norm(beta(1:(end-1)),2)  ];
         end

         
         %%% dual variable
         munew = mu + rho*(xnew - ynew);
          
         %% residual
         res_xy_track(i) = norm(xnew-ynew);
         res_x_track(i) = norm(xnew -x);
         if mod(i,50) == 0 && options.display == 1
             disp(sprintf('ADMM iter = %d with res_xy = %4.5f, res_x = %4.5f',...
                       i, res_xy_track(i),res_x_track(i))); 
         end
         
         if (res_xy_track(i) + res_x_track(i))/2 < eps
             
%              if options.display
                 disp(sprintf('Converge at ADMM iter = %d with res_xy = %4.5f, res_x = %4.5f',...
                       i, res_xy_track(i),res_x_track(i))); 
%              end
             break;
         else
             x = xnew; y = ynew;   mu = munew;  
             if i == MaxIter
                 if options.display
                     disp(sprintf('Max Iter. = %d with res_xy = %4.5f, res_x = %4.5f',...
                           i, res_xy_track(i),res_x_track(i))); 
                 end
             end
             
         end
          
     end
     
     num_iter = i;
     x_sol = xnew;
     obj_sol = d.'*x_sol;
     
      
end