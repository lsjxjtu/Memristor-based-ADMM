function [rho_best,iter_summary, error_summary] = PerfEval(obj_LP_ip, obj_LP_ad, iter_LP_ad, rho_vec,var_hardware_vec, n_vec, fig_flag)

    Ntrial = size(obj_LP_ip,1); N = size(obj_LP_ip,2); Nrho = length(rho_vec); Nvar = length(var_hardware_vec);
    
    %%% best rho
    iter_allrho = [];
    for i_rho = 1: Nrho
        iter_N_temp = [];
        for i = 1:N
            iter_rho_sum_temp = [];
            for j = 1:Ntrial
                iter_temp_rho = iter_LP_ad{j,i}(:,i_rho);
                iter_temp_rho(isnan(iter_temp_rho)) = [];
                 if ~isempty(iter_temp_rho)
                    iter_rho_sum_temp = [iter_rho_sum_temp; mean(iter_temp_rho)];
                end
            end
            if ~isempty(iter_rho_sum_temp)
                iter_N_temp =  [iter_N_temp;mean(iter_rho_sum_temp)];
            end
        end
        if ~isempty(iter_N_temp)
            iter_allrho(i_rho) = mean(iter_N_temp);
        else
            iter_allrho(i_rho)= inf;
        end
    end
    
    [~,idx_temp]= sort(iter_allrho,'ascend');
    rho_best = rho_vec(idx_temp(1));
    idx_rho_sel = idx_temp(1);
    
    %%% iterations, fix rho
    iter_summary = nan(N,Nvar);
    for i = 1:N
        for i_var = 1:Nvar
            iter_rho_sum_temp = [];
            for j = 1:Ntrial
                iter_temp = iter_LP_ad{j,i}(i_var,idx_rho_sel);
                iter_temp(isnan(iter_temp)) = [];
                if ~isempty(iter_temp)
                    iter_rho_sum_temp = [iter_rho_sum_temp; iter_temp];
                end
            end
            if ~isempty(iter_rho_sum_temp)
                iter_summary(i,i_var) = mean(iter_rho_sum_temp);
            else
                test = 1;
            end
        end
    end
    
    
    %% for different rho
    iter_summary2 = nan(N,Nrho);
    for i = 1:N
        for i_rho = 1: Nrho
            iter_rho_sum_temp = [];
            for i_var = 1:Nvar
                for j = 1:Ntrial
                    iter_temp = iter_LP_ad{j,i}(i_var,i_rho);
                    iter_temp(isnan(iter_temp)) = [];
                    if ~isempty(iter_temp)
                        iter_rho_sum_temp = [iter_rho_sum_temp; iter_temp];
                    end
                end %% trial.
            end %% var.
            if ~isempty(iter_rho_sum_temp)
                iter_summary2(i,i_rho) = mean(iter_rho_sum_temp);
            end
        end %%% rho.
    end %%% N
    
    %%% errors
    error_summary = nan(N,Nvar);  obj_ip_temp0 = [];
    for i = 1:N
        for i_var = 1:Nvar
             obj_ad_temp = [];
             obj_ip_temp = [];  
             for j = 1:Ntrial
                 if ~isnan( obj_LP_ip{j,i}(1) )
                     if i_var == 1
                        obj_ip_temp0 = [obj_ip_temp0; obj_LP_ip{j,i}(1)];
                     end
                 end
                 if ~isnan( obj_LP_ip{j,i}(i_var) )
                     obj_ad_temp = [obj_ad_temp; obj_LP_ad{j,i}(i_var,idx_rho_sel)];
                     obj_ip_temp = [obj_ip_temp; obj_LP_ip{j,i}(1)];
                 end
             end
             if ~isempty(obj_ad_temp)
                  error_summary(i,i_var) = norm(obj_ad_temp-obj_ip_temp)/length(obj_ip_temp);
             end
        end
    end
    
    error_summary = error_summary/abs(mean(obj_ip_temp0));
    
    obj_ad_N_Nvar = [];
    obj_ip_N = [];
    for i = 1:N
        obj_ad_N_Nvar_temp = [];
        obj_ip_N_temp = [];
        for i_var = Nvar
             for j = 1:Ntrial
                 if ~isnan( obj_LP_ip{j,i}(i_var) )
                     obj_ad_N_Nvar_temp = [obj_ad_N_Nvar_temp; obj_LP_ad{j,i}(i_var,idx_rho_sel)];
                     obj_ip_N_temp = [obj_ip_N_temp; obj_LP_ip{j,i}(1)];
                 end
             end
        end
        obj_ad_N_Nvar = [obj_ad_N_Nvar; mean(obj_ad_N_Nvar_temp)];
        obj_ip_N = [obj_ip_N; mean(obj_ip_N_temp)];
    end
    
    
    %%% plots
    if fig_flag == 1
               
        Marker_vec = {'o','s','^','d'};col_vec = {'r','b','m','g'};



        hfig = figure;
        str_plot = []; iter = 1;
       % N_vec_sel =[1 3 5 6 ];
        for i = 1:size(error_summary,1)
            plot(var_hardware_vec, error_summary(i,:)*100,'Marker',Marker_vec{i},'LineStyle','-','Color',col_vec{i},'MarkerEdgeColor',col_vec{i},'MarkerFaceColor',col_vec{i},'MarkerSize',8,'LineWidth',2);
            hold on;
            str_plot{iter} = sprintf('Dimension %d',2*n_vec(i));
            iter = iter+1;
        end
        xlabel('Hardware variation (%)');
        ylabel('Error to interior-point without variation (%)');
        legend(str_plot);
        

        
    end
 
end