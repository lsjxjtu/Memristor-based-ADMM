%%%% Memristor-Algorithm Cooptimization
%%%% Author: Sijia Liu
%%%% Please cite paper: "A Memristor-Based Optimization Framework for AI Applications" 

clc; clear all; close all;

code1 = 0; %% Linear program (LP)
code2 = 0; %% Quadratic program (QP)
code3 = 0; %% Compressive sensing (CS), sparse learning
code4 = 1; %% Power Iteration (PI)

if code1 == 1
    %%%% parameter setting
    n_vec = [10, 25, 50, 100, 300, 500]; %%% problem size range
    l = 2; %%% number of constraints
    N_trials = 50; %%% number of simulation trials
    var_hardware_vec = [0, 2, 5, 10]; %% percentage of hardware variations, it applies to coefficient matrix 
    rho_vec = [0.1, 1, 10, 100]; %%% ADMM augmented parameter // check the effect of ADMM parameter

    
    
%     %%%% generate problem data
%     Data.d_LP = cell(N_trials,length(n_vec));
%     Data.G_LP = cell(N_trials,length(n_vec));
%     Data.h_LP = cell(N_trials,length(n_vec));
%     Data.obj_opt_LP = cell(N_trials,length(n_vec));
%     Data.sol_opt_LP = cell(N_trials,length(n_vec));
%     Data.d_QP = cell(N_trials,length(n_vec));
%     Data.G_QP = cell(N_trials,length(n_vec));
%     Data.h_QP = cell(N_trials,length(n_vec));
%     Data.obj_opt_QP = cell(N_trials,length(n_vec));
%     Data.sol_opt_QP = cell(N_trials,length(n_vec));
%     for i = 1:length(n_vec)
%         n = n_vec(i); %l = l_vec(i);
%         for i_trial = 1:N_trials
%             d = [randn(n,1);zeros(n+l,1)]; %% setting coefficients in LP & QP
%             G = [randn(l,n), -eye(l), zeros(l,n); eye(n), zeros(n,l), eye(n)];
%             h = [rand(l,1); ones(n,1)]; %% x \in [0, 1]
%             cvx_begin   quiet
%                 variable x(2*n+l);
%                 minimize (d.'*x);
%                 subject to
%                     G*x == h;
%                     x >= zeros(2*n+l,1);
%             cvx_end
%             if strcmp(cvx_status,'Solved') && ~isnan(cvx_optval)
%                 Data.d_LP{i_trial,i} = d;
%                 Data.G_LP{i_trial,i} = G;
%                 Data.h_LP{i_trial,i} = h;
%                 Data.obj_opt_LP{i_trial,i} = cvx_optval;
%                 Data.sol_opt_LP{i_trial,i} = x;
%                 disp(sprintf('Valid problem setting, trial = %d, n = %d, LP = %2.3f', i_trial, n,Data.obj_opt_LP{i_trial,i}));
%             end
% 
%         end
%     end
%     
%     
%     for i = 1:length(n_vec)
%         n = n_vec(i); l = 1;
%         for i_trial = 1:N_trials
%             d = [randn(n,1);zeros(n+l,1)]; %% setting coefficients in LP & QP
%             G = [randn(l,n), -eye(l), zeros(l,n); eye(n), zeros(n,l), eye(n)];
%             h = [rand(l,1); ones(n,1)]; %% x \in [0, 1]
%             cvx_begin  quiet
%                 variable x(2*n+l);
%                 minimize (d.'*x);
%                 subject to
%                         G*x == h;
%                         norm(x(1:(end-1)),2) <= x(end);
%             cvx_end
%             if strcmp(cvx_status,'Solved') && ~isnan(cvx_optval)
%                 Data.d_QP{i_trial,i} = d;
%                 Data.G_QP{i_trial,i} = G;
%                 Data.h_QP{i_trial,i} = h;
%                 Data.obj_opt_QP{i_trial,i} = cvx_optval;
%                 Data.sol_opt_QP{i_trial,i} = x;
%                 disp(sprintf('Valid problem setting, trial = %d, n = %d, QP = %2.3f', i_trial, n,Data.obj_opt_QP{i_trial,i}));
%             end
% 
%         end
%     end
%     
%     save('ProblemData_LP_QP.mat','Data');

    load ProblemData_LP_QP;
    
    %%%% Linear program
        
    sol_LP_ip =  cell(N_trials,length(n_vec)); 
    sol_LP_ad =  cell(N_trials,length(n_vec));
    obj_LP_ip =  cell(N_trials,length(n_vec)); 
    obj_LP_ad =  cell(N_trials,length(n_vec));
    iter_LP_ad =  cell(N_trials,length(n_vec));
    for i = 1:length(n_vec)

            n = n_vec(i);  

            for i_trial = 1:N_trials
                %%% problem data for LP
                d_LP = Data.d_LP{i_trial,i};
                G_LP = Data.G_LP{i_trial,i};
                h_LP = Data.h_LP{i_trial,i};
                dim = length(d_LP);

                sol_LP_ip{i_trial,i} = nan(dim,length(var_hardware_vec));
                obj_LP_ip{i_trial,i} = nan(length(var_hardware_vec),1);

                sol_LP_ad{i_trial,i} = nan(dim,length(var_hardware_vec),length(rho_vec));    
                obj_LP_ad{i_trial,i} = nan(length(var_hardware_vec),length(rho_vec));    
                iter_LP_ad{i_trial,i} = nan(length(var_hardware_vec),length(rho_vec));    
                
               
               
                %%% obj: Data.obj_opt_LP{i_trial,i};
                %%% sol: Data.sol_opt_LP{i_trial,i};
                
                if isempty(d_LP)
                    continue;
                end
                

                for i_hard_var = 1: length(var_hardware_vec) %%% when var = 0, solution is the optimal one

                    var_hardware = var_hardware_vec(i_hard_var);
                    G_LP_noise = HardwareVarNoise(G_LP, var_hardware/100);

                    %%% variation may lead to an infeasbile problem;
                    cvx_begin  quiet
                        variable x(dim);
                        minimize (d_LP.'*x);
                        subject to
                            G_LP_noise*x == h_LP;
                            x >= zeros(dim,1);
                    cvx_end
                    if ~strcmp(cvx_status,'Solved') || isnan(cvx_optval)
                       disp(sprintf('Infeasible due to variation, n = %d, trial = %d', n,i_trial ));
                       continue;
                    end
                    %%% G_LP_noise full row rank
                    eig_value = eigs(G_LP_noise*G_LP_noise.',1,'SM');
                    if abs(eig_value) < 1e-10
                        disp(sprintf('Non full row rank for G, n = %d, trial = %d', n,i_trial ));
                       continue;
                    end
                    
                    %%% problem is feasible
                    sol_LP_ip{i_trial,i}(:,i_hard_var) = x;
                    obj_LP_ip{i_trial,i}(i_hard_var) = cvx_optval;

                    for i_rho = 1:length(rho_vec) 

                        %%%% set ADMM parameter
                        options.rho = rho_vec(i_rho);
                        options.d = d_LP;
                        options.G = G_LP_noise;
                        options.h = h_LP;
                        options.eps = 1e-3;
                        options.MaxIter = 1e4;
                        options.display = 1;
                        %%%% 
                        [x_sol,obj_sol,res_xy_track, res_x_track, num_iter_ad] = ADMM_mem_LP(options);
                        sol_LP_ad{i_trial,i}(:,i_hard_var,i_rho) = x_sol;
                        obj_LP_ad{i_trial,i}(i_hard_var,i_rho) = obj_sol;
                        iter_LP_ad{i_trial,i}(i_hard_var,i_rho) = num_iter_ad;
                    end  

                end %% hardware variation

            end %%% random trials

    end %%% problem dimension
    
    
    %%% performance evaluation
    %%% input: obj_LP_ip obj_LP_ad iter_LP_ad
    [rho_best,iter_summary, error_summary] = PerfEval(obj_LP_ip, obj_LP_ad, iter_LP_ad, rho_vec,var_hardware_vec, n_vec, 1);

 
    
end


if code2 == 1
    %%%% parameter setting
    n_vec = [10, 25, 50, 100, 300, 500]; %% logspace(1,3,5) %%% problem size ranging from 10 to 1e3
    l = 2; %%% number of constraints
    N_trials = 50; %%% number of simulation trials
    var_hardware_vec = [0, 2, 5, 10]; %% percentage of hardware variations, it applies to coefficient matrix G 
    rho_vec = [0.1, 1, 10, 100]; %%% ADMM augmented parameter // check the effect of ADMM parameter
    
    load ProblemData_LP_QP;
    
    %%%% Quadratic program
        
    sol_QP_ip =  cell(N_trials,length(n_vec)); 
    sol_QP_ad =  cell(N_trials,length(n_vec));
    obj_QP_ip =  cell(N_trials,length(n_vec)); 
    obj_QP_ad =  cell(N_trials,length(n_vec));
    iter_QP_ad =  cell(N_trials,length(n_vec));
    
    for i = 1:length(n_vec)

            n = n_vec(i);  
            
            for i_trial = 1:N_trials
                %%% problem data for QP
                d_QP = Data.d_QP{i_trial,i};
                G_QP = Data.G_QP{i_trial,i};
                h_QP = Data.h_QP{i_trial,i};
                dim = length(d_QP);
                
                sol_QP_ip{i_trial,i} = nan(dim,length(var_hardware_vec));
                obj_QP_ip{i_trial,i} = nan(length(var_hardware_vec),1);

                sol_QP_ad{i_trial,i} = nan(dim,length(var_hardware_vec),length(rho_vec));    
                obj_QP_ad{i_trial,i} = nan(length(var_hardware_vec),length(rho_vec));    
                iter_QP_ad{i_trial,i} = nan(length(var_hardware_vec),length(rho_vec));    
                if isempty(d_QP)
                    continue;
                end
                
                for i_hard_var = 1: length(var_hardware_vec) %%% when var = 0, solution is the optimal one
                    var_hardware = var_hardware_vec(i_hard_var);
                    G_QP_noise = HardwareVarNoise(G_QP, var_hardware/100);
                    %%% variation may lead to an infeasbile problem;
                    cvx_begin  quiet
                        variable x(dim);
                        minimize (d_QP.'*x);
                        subject to
                            G_QP_noise*x == h_QP;
                            norm(x(1:(end-1)),2) <= x(end);
                    cvx_end

                    if ~strcmp(cvx_status,'Solved') || isnan(cvx_optval)
                       disp(sprintf('Infeasible due to variation, n = %d, trial = %d', n,i_trial ));
                       continue;
                    end
                    %%% G_LP_noise full row rank
                    eig_value = eigs(G_QP_noise*G_QP_noise.',1,'SM');
                    if abs(eig_value) < 1e-10
                        disp(sprintf('Non full row rank for G, n = %d, trial = %d', n,i_trial ));
                       continue;
                    end
                    
                    %%% problem is feasible
                    sol_QP_ip{i_trial,i}(:,i_hard_var) = x;
                    obj_QP_ip{i_trial,i}(i_hard_var) = cvx_optval;
                    
                    for i_rho = 1:length(rho_vec) 
                        
                        %%%% set ADMM parameter
                        options.rho = rho_vec(i_rho);
                        options.d = d_QP;
                        options.G = G_QP_noise;
                        options.h = h_QP;
                        options.eps = 1e-3;
                        options.MaxIter = 1e5;
                        options.display = 1;
                        %%%% 
                        [x_sol,obj_sol,res_xy_track, res_x_track, num_iter_ad] = ADMM_mem_QP(options);
                        sol_QP_ad{i_trial,i}(:,i_hard_var,i_rho) = x_sol;
                        obj_QP_ad{i_trial,i}(i_hard_var,i_rho) = obj_sol;
                        iter_QP_ad{i_trial,i}(i_hard_var,i_rho) = num_iter_ad;
                        
                    end %%% ADMM rho
                    
                end %%% hard. var.
                disp(sprintf('Trial = %d, N = %d',i_trial, n_vec(i)));
            end %%% trial
            
    end %%% dimension
    
    %%% performance evaluation
    [rho_best,iter_summary, error_summary] = PerfEval_QP(obj_QP_ip, obj_QP_ad, iter_QP_ad, rho_vec,var_hardware_vec, n_vec, 1);

 

end


if code3 == 1
   
    p = 1024; 
    sparse_vec = [10, 50, 100, 150,  200];
    q = 500; %%% number of constraints
    N_trials = 10; %%% number of simulation trials
    var_hardware_vec = [0, 2, 5, 10]; %% percentage of hardware variations, it applies to coefficient matrix G 
    rho_vec = [0.1, 1, 10, 100]; %%% ADMM augmented parameter // check the effect of ADMM parameter
    sigma = 1e-2;
    eps_error = 1e-3;
    
%     Data.h = cell(N_trials,length(sparse_vec));
%     Data.H = cell(N_trials,length(sparse_vec));
%     Data.obj_opt = cell(N_trials,length(sparse_vec));
%     Data.sol_opt = cell(N_trials,length(sparse_vec));
%     Data.obj_OMP = cell(N_trials,length(sparse_vec));
%     Data.sol_OMP = cell(N_trials,length(sparse_vec));
%     
%     for i = 1:length(sparse_vec)
%         k_sparse = sparse_vec(i); %l = l_vec(i);
%         for i_trial = 1:N_trials
%             
%             x_star = zeros(p,1); 
%             position_nzeros = randperm(p,k_sparse);
%             x_star(position_nzeros) = randn(k_sparse,1) + 1;
%             H = randn(q,p);
%             noise = randn(q,1)*sqrt(sigma);
%             h = H*x_star + noise;
%  
% %             cvx_begin   quiet
% %                 variable x(p);
% %                 minimize ( norm(x,1) );
% %                 subject to
% %                     norm(H*x -h,2) <= eps_error;
% %             cvx_end
%             
%             x_OMP = OMP( H, h, eps_error );
%             
%             if  norm(x_OMP-x_star)/k_sparse < max(eps_error,0.1)
%                 Data.H{i_trial,i} = H;
%                 Data.h{i_trial,i} = h;
%                 Data.obj_opt{i_trial,i} = norm(x_star,1);
%                 Data.sol_opt{i_trial,i} = x_star;
%                 Data.sol_OMP{i_trial,i} = x_OMP;
%                 Data.obj_OMP{i_trial,i} = norm(x_OMP,1);
%                 disp(sprintf('Valid problem setting, trial = %d, ksparse = %d, obj = %2.3f', i_trial, sparse_vec(i), Data.obj_opt{i_trial,i}));
%             end
% 
%         end
%         
%     end
%     
%     save('ProblemData_CS.mat','Data');
     
    load ProblemData_CS;
    
    sol_CS_ad =  cell(N_trials,length(sparse_vec));
    obj_CS_ad =  cell(N_trials,length(sparse_vec));
    iter_CS_ad =  cell(N_trials,length(sparse_vec));
    
    for i = 1:length(sparse_vec) %%% sparse para. 
        n_sparse = sparse_vec(i);
        for i_trial = 1:N_trials
            
            %%% problem data for QP
            H_CS = Data.H{i_trial,i};
            h_CS = Data.h{i_trial,i};
            dim = size(H_CS,2);
            sol_CS_ad{i_trial,i} = nan(dim,length(var_hardware_vec),length(rho_vec));
            obj_CS_ad{i_trial,i} = nan(length(var_hardware_vec),length(rho_vec));
            iter_CS_ad{i_trial,i} = nan(length(var_hardware_vec),length(rho_vec));    
            if isempty(h_CS)
               continue;
            end
            
            for i_hard_var = 1: length(var_hardware_vec) %%% when var = 0, solution is the optimal one
                var_hardware = var_hardware_vec(i_hard_var);
                H_CS_noise = HardwareVarNoise(H_CS, var_hardware/100);
                %%% variation may lead to an infeasbile problem;
%                 cvx_begin   %quiet
%                     variable x(dim);
%                     minimize ( norm(x,1) );
%                     subject to
%                         norm(H_CS_noise*x -h_CS,2) <= eps_error;
%                 cvx_end
%                 if ~strcmp(cvx_status,'Solved') || isnan(cvx_optval)
%                        disp(sprintf('Infeasible due to variation, k_sparse = %d, trial = %d, var = %d%%', n_sparse,i_trial,var_hardware ));
%                        continue;
%                 end
%                 x_OMP = OMP( H_CS_noise, h_CS, eps_error );
                
                for i_rho = 1:length(rho_vec) 
                    %%%% set ADMM parameter
                    options.rho = rho_vec(i_rho);
                    options.H = H_CS_noise;
                    options.h = h_CS;
                    options.eps = 1e-3;
                    options.eps_error = eps_error;
                    options.MaxIter = 1e4;
                    options.display = 1;
                    
                    [x_sol,obj_sol,res_xy_track, res_x_track, num_iter_ad] = ADMM_mem_CS(options);    
                    sol_CS_ad{i_trial,i}(:,i_hard_var,i_rho) = x_sol;
                    obj_CS_ad{i_trial,i}(i_hard_var,i_rho) = obj_sol;
                    iter_CS_ad{i_trial,i}(i_hard_var,i_rho) = num_iter_ad;
                end %% rho
                
            end %%% var
            disp(sprintf('Trial = %d, N = %d',i_trial, sparse_vec(i)));
        end %%% Ntrial
    end %%% sparse
    
    %%% performance evaluation
    [rho_best,iter_summary, error_summary] = PerfEval_CS(Data.sol_opt, Data.sol_OMP,...
        sol_CS_ad, obj_CS_ad, iter_CS_ad,N_trials, rho_vec,var_hardware_vec, sparse_vec, 1);


    
end

if code4 == 1
    n = 50;Ntrial = 50;
%     options.N_PI = 1e4; 
    options.eps_PI = 1e-5; %%% convergence tolerance
%     options.eps_ini = 1e-5; 
    options.eps_zero = 1e-5; %%% zero tolerance
    options.message = 1; %%% display message
    options.linearDepTrial = 5; %% number of random initializations
   
    k_repeat_vec = [1:10];
    error_PI = zeros(Ntrial, length(k_repeat_vec));
    Iter_PI = zeros(Ntrial, length(k_repeat_vec));
    multiplicity_PI = zeros(Ntrial, length(k_repeat_vec));
    
%     DataA = cell(length(k_repeat_vec) , Ntrial);
%     
%     for i = 1:Ntrial
%         A = randn(n,n); A = 0.5*(A + A.');
%         [V,D] = eig(A); eig_A = diag(D);
%         [~,idx_eigA] = sort(abs(diag(D)),'descend');
%         eig_A = eig_A(idx_eigA); V= V(:,idx_eigA);            
%         for j = 1:length(k_repeat_vec) 
%             k_repeat = k_repeat_vec(j);
%             eig_A(1:k_repeat) = eig_A(1); %%% repeated eigenvalue
%             A = V*diag(eig_A)*V.'; %%% update A
%             if norm(sort(real(eig(A))) - sort(eig_A)) > 1e-5
%                 error('Matrix construction error!');
%             end
%             DataA{j,i} = A;
%         end
%     end
%     
%     save('ProblemData_PI.mat','DataA');

    load ProblemData_PI;
    
    %%% PI for dominant eigenvalue
    for i = 1:Ntrial
        for j = 1:length(k_repeat_vec) %% repeated times of the dominant eigenvalue
            A = DataA{j,i};
            [lam_est, V_est,iter_rand_initial,iter_PI,error_lam] = PI_generalized(A, options);
            error_PI(i,j) = error_lam;
            Iter_PI(i,j) = iter_PI;
            multiplicity_PI(i,j) = size(V_est,2);
        end
    end
    
    hfig = figure; subplot(3,1,1);
    plot(k_repeat_vec,mean(error_PI,1),'-rs',...
        'LineWidth',2,...
        'MarkerSize',10,...
        'MarkerEdgeColor','b',...
        'MarkerFaceColor',[0.5,0.5,0.5]);
    ylabel('Error');
    subplot(3,1,2);
    accuracy_mul = zeros(size(multiplicity_PI,2),1);
    for i = 1: size(multiplicity_PI,2)
        accuracy_mul(i) = mean(multiplicity_PI(:,i))/k_repeat_vec(i)*100;
    end
    stem(k_repeat_vec,accuracy_mul,'LineStyle','-.',...
         'MarkerFaceColor',[0.5,0.5,0.5],...
         'MarkerEdgeColor','b');
    ylabel('Multiplicity accuracy(%)');
    subplot(3,1,3);
    boxplot(log2(Iter_PI+0.5)+1,k_repeat_vec); hold on;
    xlabel('Algebraic multiplicity of dominanat eigenvalue');
    ylabel('# of iterations');
    
    %%% PCA example 
    load fisheriris.mat           % array of size 150 x 5
    spec = zeros( size(meas,1), 1 );
    
    spec(cell2mat(cellfun(@(x) find(strcmp(species,x )), {'setosa'} , 'UniformOutput',false))) = 0;
    spec(cell2mat(cellfun(@(x) find(strcmp(x,species)), {'versicolor'}, 'UniformOutput',false))) = 1;
    spec(cell2mat(cellfun(@(x) find(strcmp(x,species)), {'virginica'}, 'UniformOutput',false))) = 2; 
    
    X = meas(:,1:4)';       % 150 columns of length 4; 4 \times 150
    n = size(X,2);              %%% 150 observations 
    
    Xmean = mean(X,2) ;          % find mean
    A = X - Xmean*ones(1,n);    % subtract mean from each point
    Cov = A*A.'; 
    
    [U,S,V] = svd(Cov,'econ');    % find singular value decomposition
    sigma = diag(S);             % singular values
    C = ( A.'*U(:,1:2) ).';

    hfig = figure; subplot(1,2,1);
    for i = 0:2
        scatter(C(1,find(spec==i)),C(2,find(spec==i)),17,spec(find(spec==i)),'filled'); hold on;
    end
    xlabel(sprintf('PC1, variance %1.2f',sigma(1)/sum(sigma)*100)); ylabel(sprintf('PC2, variance %1.2f',sum(sigma(2))/sum(sigma)*100));
    legend( unique(species) );
    
    %%% our approach
    [ lam_est, V_est,iter_PI,error_lam ] =   PI_generalized_decomp(Cov, 2, options);
    for i = 1:size(V_est,2)
        if corr(V_est(:,i),U(:,i)) < 0
            V_est(:,i) = - V_est(:,i);
        end
    end
    Cproj = ( A.'*V_est ).';
    subplot(1,2,2);
    for i = 0:2
        scatter(Cproj(1,find(spec==i)),Cproj(2,find(spec==i)),17,spec(find(spec==i)),'filled'); hold on;
    end
     xlabel(sprintf('PC1, variance %1.2f',lam_est(1)/sum(sigma)*100)); ylabel(sprintf('PC2, variance %1.2f',sum(lam_est(2))/sum(sigma)*100));

    legend( unique(species) );
end
 

