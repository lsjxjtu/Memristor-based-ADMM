function  [C_map, c_map] = linearMapMem(C)
    
    n = size(C,1);
    C_pos = C; 
    C_pos( find(C_pos <=0) ) = 0;
    C_neg = -C; C_neg( find(C_neg <=0) ) = 0;
    idx_sel = find( sum(C_neg,1) > 0 );
    idx_remove = find( sum(C_neg,1) == 0 );
    B = C_neg(:,idx_sel);
    D = eye(n);
    D(idx_remove,:) = [];
    n_bar = size(D,1);
    
    C_map = [ C_pos, B; D, eye(n_bar) ];
    c_map = [ zeros(n_bar,1)];
end