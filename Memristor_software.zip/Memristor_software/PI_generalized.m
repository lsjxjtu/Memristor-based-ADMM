function [lam_est, V_est,iter_rand_initial,iter_PI,error_lam] = PI_generalized(A, options)
    
    n = size(A,1);
    eps_PI = options.eps_PI; 
%     eps_ini = options.eps_ini; 
    eps_zero = options.eps_zero;
    flag_message = options.message;
    trialdep = options.linearDepTrial; %%% number of testing linear dependence

    
    V_est = []; lam_est = [];
    U_multi_ini = [];  
    iter_rand_initial = 0;
    iter_PI = 0;
    iter_depenent = 0;
    
    %%% ground truth
    [V,D] = eig(A); eig_A = diag(D);
    [~,idx_eigA] = sort(abs(diag(D)),'descend');
    eig_A = eig_A(idx_eigA);  V= V(:,idx_eigA);
    multiplicity = length(find(abs(eig_A-eig_A(1))<=1e-6));
    V_A_dominant = V(:,find(abs(eig_A-eig_A(1))<=1e-6));
    
    %%% PI method
    while 1
        %%% PI
        u = randn(n,1);  %% initial point
        iter_rand_initial = iter_rand_initial + 1; %%% times of random initialization
       
        while 1
            iter_PI = iter_PI + 1;
            unew = A*u/norm(A*u,2); %%% PI step
            
            if mod(iter_PI,100) == 0
                if flag_message
                   disp(sprintf('Ave. PI iter = %d, Initial_iter = %d, error = %3.5f', fix(iter_PI/iter_rand_initial),iter_rand_initial,  min( norm(u - unew),norm(u + unew) ) ));
                end
            end
            
            if norm(u - unew) <= eps_PI || norm(u + unew)  <= eps_PI %% the latter corresponds to the case + - + -...
                break; %% PI converges
            else
                u = unew;
            end
        end %%% PI converges
        
        U_multi_ini = [U_multi_ini, unew]; %% random initial ponits

        if iter_rand_initial < 2
            continue;
        else
%             lam_multiple_ini = [];
%             for i = 1:size(U_multi_ini,2)
%                 lam_multiple_ini = [lam_multiple_ini; U_multi_ini(:,i).'* A * U_multi_ini(:,i)/( U_multi_ini(:,i).'* U_multi_ini(:,i) )];
%             end
                        
            if abs( det( U_multi_ini.'*U_multi_ini ) ) < eps_zero %%% linearly dependent


                iter_depenent = iter_depenent + 1; 
                if iter_depenent <= trialdep %%% test another random initial ponit
                    U_multi_ini(:,end) = [];  
                    continue;
                end

    %                     [Q_orth, R_temp] = Gram_Schmidt(U_multi_ini(:,1:(end-1)));
                %%% linearly independent at most (end-1) columns        
                [Q_orth] = Gram_Schmidt(U_multi_ini(:,1:(end-1))); 
                if norm(Q_orth.'*Q_orth - eye(size(Q_orth,2)),'fro') > 1e-5 %% orthogonal basis
                   error('error in Gram_Schmidt!');
                end

                V_est = Q_orth;
                for i_temp = 1:size(V_est,2)
                    lam_est(i_temp) = Q_orth(:,i_temp).'* A * Q_orth(:,i_temp)/( Q_orth(:,i_temp).' * Q_orth(:,i_temp) );
                end
                if multiplicity ~= size(V_est,2)
                    test = 1;
                end

                disp(sprintf('Converge at ave. PI iter = %d, multiplicity = %d, error = %3.5f', fix(iter_PI/iter_rand_initial), size(V_est,2), norm(mean(lam_est)-eig_A(1)) ))



                break;

            else %%  %%% linearly independent

                continue; %%% update U_multi_ini

            end
        
        end

    end %%% outer iteration
    iter_PI = fix(iter_PI/iter_rand_initial);
    error_lam = 0;
    for i_temp = 1:size(V_est,2) %%% eigenvalue error
        error_lam = error_lam + abs(V_est(:,i_temp).'* A * V_est(:,i_temp)/( V_est(:,i_temp).' * V_est(:,i_temp) ) - eig_A(1));
    end
    error_lam = error_lam/size(V_est,2);
end