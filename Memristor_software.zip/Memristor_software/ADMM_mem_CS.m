function [x_sol,obj_sol,res_xy_track, res_x_track, num_iter] = ADMM_mem_CS(options)

     rho = options.rho;
     H = options.H;
     h = options.h;
     eps = options.eps;
     eps_error = options.eps_error;
     MaxIter = options.MaxIter;
     
     n = size(H,2); 
     l = size(H,1);
     
     z_var = zeros(n,1); w_var = z_var; 
     s_var = zeros(l,1); u_var = s_var; 
     mu1 = z_var; mu2 = s_var;
     
     C = [ rho*eye(n), zeros(n,l), H.';  zeros(l,n),  rho*eye(l), -eye(l);  H, -eye(l), zeros(l,l) ];  
     [C_map, c_map] = linearMapMem(C);
     
     eig_value = eigs(C,1,'SM');
     if abs(eig_value) < 1e-10
          error('error in invertible C!');
     end
     
     Cinv = inv(C); C_mapinv = inv(C_map);
     
     for i = 1:MaxIter
         %%% x-step
         alpha1 = w_var - (1/rho)*( mu1 );
         alpha2 = u_var - (1/rho)*( mu2 );
         c = [ rho*alpha1; rho*alpha2; h ];
         c_map_ex = [c; c_map];
         %%% Cx = c; C_map x_ex = c_map
         x_ex = C_mapinv*c_map_ex;
         znew = x_ex(1:length(alpha1)); 
         snew = x_ex( (length(alpha1)+1):(length(alpha1)+length(alpha2)) );
         x_test = Cinv*c;
         if max(abs([znew;snew] - x_test(1:(l+n)))) > 1e-3
             error('error in mem. mapping!');
         end
             
         %%% y-step
         beta1 = znew + (1/rho)*(mu1);
         beta2 = snew + (1/rho)*(mu2);
         
         wnew = (beta1 - (1/rho)*ones(n,1)).*( (beta1 - (1/rho)*ones(n,1))>0 ) - (-beta1 - (1/rho)*ones(n,1)).*( (-beta1 - (1/rho)*ones(n,1))>0 );
         
         unew = min(eps_error,norm(beta2))*beta2/norm(beta2); 
         
         %%% dual variable
         mu1new = mu1 + rho*(znew - wnew);
         mu2new = mu2 + rho*(snew - unew); 
         
         %% residual
         res_xy_track(i) = norm(znew - wnew)/2 + norm(snew - unew)/2;
         res_x_track(i) = norm(znew -z_var)/2 + norm(snew -s_var)/2;
         if mod(i,50) == 0 && options.display == 1
             disp(sprintf('ADMM iter = %d with res_xy = %4.5f, res_x = %4.5f',...
                       i, res_xy_track(i),res_x_track(i))); 
         end
         
         if (res_xy_track(i) + res_x_track(i))/2 < eps
             
             if options.display
                 disp(sprintf('Converge at ADMM iter = %d with res_xy = %4.5f, res_x = %4.5f',...
                       i, res_xy_track(i),res_x_track(i))); 
             end
             break;
         else
              z_var = znew; w_var = wnew; 
             s_var = snew; u_var = unew; 
              mu1 = mu1new;  mu2 = mu2new;  
             if i == MaxIter
                 if options.display
                     disp(sprintf('Max Iter. = %d with res_xy = %4.5f, res_x = %4.5f',...
                           i, res_xy_track(i),res_x_track(i))); 
                 end
             end
             
         end
          
     end
     
     num_iter = i;
     x_sol = wnew;
     obj_sol = norm(wnew,1);
end