function [rho_best,iter_summary, error_summary] = PerfEval_CS(sol_opt, sol_OMP,...
sol_CS_ad, obj_CS_ad, iter_CS_ad,Ntrial, rho_vec,var_hardware_vec, n_vec, fig_flag)
   
    N = size(obj_CS_ad,2); %% sparse para.
    Nrho = length(rho_vec); Nvar = length(var_hardware_vec);
    
    %%% best rho
    iter_allrho = [];
    for i_rho = 1: Nrho
        iter_N_temp = [];
        for i = 1:N
            iter_rho_sum_temp = [];
            for j = 1:Ntrial
                iter_temp_rho = iter_CS_ad{j,i}(:,i_rho);
                iter_temp_rho(isnan(iter_temp_rho)) = [];
                 if ~isempty(iter_temp_rho)
                    iter_rho_sum_temp = [iter_rho_sum_temp; mean(iter_temp_rho)];
                end
            end
            if ~isempty(iter_rho_sum_temp)
                iter_N_temp =  [iter_N_temp;mean(iter_rho_sum_temp)];
            end
        end
        if ~isempty(iter_N_temp)
            iter_allrho(i_rho) = mean(iter_N_temp);
        else
            iter_allrho(i_rho)= inf;
        end
    end
    
    [~,idx_temp]= sort(iter_allrho,'ascend');
    rho_best = rho_vec(idx_temp(1));
    idx_rho_sel = idx_temp(1);
    
    %%% iterations, fix rho
    iter_summary = nan(N,Nvar);
    for i = 1:N
        for i_var = 1:Nvar
            iter_rho_sum_temp = [];
            for j = 1:Ntrial
                iter_temp = iter_CS_ad{j,i}(i_var,idx_rho_sel);
                iter_temp(isnan(iter_temp)) = [];
                if ~isempty(iter_temp)
                    iter_rho_sum_temp = [iter_rho_sum_temp; iter_temp];
                end
            end
            if ~isempty(iter_rho_sum_temp)
                iter_summary(i,i_var) = mean(iter_rho_sum_temp);
            end
        end
    end
    
    
    %% for different rho
    iter_summary2 = nan(N,Nrho);
    for i = 1:N
        for i_rho = 1: Nrho
            iter_rho_sum_temp = [];
            for i_var = 1:Nvar
                for j = 1:Ntrial
                    iter_temp = iter_CS_ad{j,i}(i_var,i_rho);
                    iter_temp(isnan(iter_temp)) = [];
                    if ~isempty(iter_temp)
                        iter_rho_sum_temp = [iter_rho_sum_temp; iter_temp];
                    end
                end %% trial.
            end %% var.
            if ~isempty(iter_rho_sum_temp)
                iter_summary2(i,i_rho) = mean(iter_rho_sum_temp);
            end
        end %%% rho.
    end %%% N
    
    
    %%% errors; fix rho
    error_summary = nan(N,Nvar);      sparse_error_summary = nan(N,Nvar);  
    error_summary_OMP = nan(N,1);      sparse_error_summary_OMP = nan(N,1);  

%     obj_ip_temp0 = [];
    for i = 1:N
        for i_var = 1:Nvar
             err_ad_temp = [];
             sparse_err_ad_temp = [];
              if i_var == 1
                  err_OMP_temp = [];  sparse_err_OMP_temp = [];  
              end
             for j = 1:Ntrial
                 if ~isnan( obj_CS_ad{j,i}(i_var,idx_rho_sel) )
                     %% admm sol. sol_CS_ad{j,i}(:,i_var,idx_rho_sel)
                     %% OMP sol. sol_OMP{j,i}
                     %% Opt sol. sol_opt{j,i}
                     
                     sol_opt_tmp = sol_opt{j,i};
                     sol_CS_tmp = zeros(length(sol_opt_tmp),1);
                     
                     idx_k_sparse = find(abs(sol_opt_tmp)>1e-12);
                     k_sparse_tmp = length(idx_k_sparse);
                     if k_sparse_tmp ~= n_vec(i)
                         error('error in sparsity')
                     end
                     
                     if i_var == 1
                         sol_OMP_tmp = zeros(length(sol_CS_tmp),1);
                         [~, idx_OMP_sort] = sort(abs(sol_OMP{j,i}),'descend');
                         idx_sparse_OMP = unique(idx_OMP_sort(1:k_sparse_tmp));
                         sol_OMP_tmp(idx_sparse_OMP) = sol_OMP{j,i}(idx_sparse_OMP);
                         err_OMP_temp = [err_OMP_temp; norm(sol_OMP_tmp-sol_opt_tmp)/norm(sol_opt_tmp)] ;
                         sparse_err_OMP_temp = [sparse_err_OMP_temp; length(setdiff(idx_k_sparse,idx_sparse_OMP))/length(sol_opt_tmp)];
                     end
                     
                     [~, idx_ad_sort] = sort(abs(sol_CS_ad{j,i}(:,i_var,idx_rho_sel)),'descend');
                     idx_sparse_ad = unique(idx_ad_sort(1:k_sparse_tmp));
                     sol_CS_tmp(idx_sparse_ad) = sol_CS_ad{j,i}(idx_sparse_ad,i_var,idx_rho_sel);
                     err_ad_temp = [err_ad_temp; norm(sol_CS_tmp-sol_opt_tmp)/norm(sol_opt_tmp)] ;
                     sparse_err_ad_temp = [sparse_err_ad_temp;  length(setdiff(idx_k_sparse,idx_sparse_ad))/length(sol_opt_tmp)];
                     
                      
                 end
             end
             if ~isempty(err_ad_temp)
                  error_summary(i,i_var) = mean(err_ad_temp);
                  sparse_error_summary(i,i_var) = mean(sparse_err_ad_temp);
             end
             if ~isempty(err_OMP_temp) && i_var == 1
                  error_summary_OMP(i,1) = mean(err_OMP_temp);
                  sparse_error_summary_OMP(i,1) = mean(sparse_err_OMP_temp);
             end
             
        end
    end
    
 
    
 
    
    %%% plots
    if fig_flag == 1
               
        Marker_vec = {'o','s','^','d'};col_vec = {'r','b','m','g'};
          
        %%% Fig2;
        hfig2 = figure; str_plot = []; iter = 1;
        for i = 1:length(var_hardware_vec)
            plot(n_vec, error_summary(:,i),'Marker',Marker_vec{i},'LineStyle','-','Color',col_vec{i},'MarkerEdgeColor',col_vec{i},'MarkerFaceColor',col_vec{i},'MarkerSize',8,'LineWidth',2);
            hold on;
            str_plot{iter} = sprintf('Hardware vari. %d%%',var_hardware_vec(i));
            iter = iter+1;
        end
        hold on;
        plot(n_vec, error_summary_OMP,'Marker','x','LineStyle','--','Color','k','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8,'LineWidth',2);
        str_plot{iter} =  sprintf('OMP, no variation');
        legend(str_plot);
        xlabel('Sparsity level');
        ylabel('Error of signal recovery');
        
%         hfig22 = figure; str_plot = []; iter = 1;
%         for i = 1:length(var_hardware_vec)
%             plot(n_vec, sparse_error_summary(:,i)*100,'Marker',Marker_vec{i},'LineStyle','-','Color',col_vec{i},'MarkerEdgeColor',col_vec{i},'MarkerFaceColor',col_vec{i},'MarkerSize',8,'LineWidth',2);
%             hold on;
%             str_plot{iter} = sprintf('Hardware vari. %d%%',var_hardware_vec(i));
%             iter = iter+1;
%         end
%         hold on;
%         plot(n_vec, sparse_error_summary_OMP*100,'Marker',Marker_vec{i},'LineStyle','--','Color','k','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8,'LineWidth',2);
%         str_plot{iter} =  sprintf('OMP, no variation');
%         legend(str_plot);
%         xlabel('Sparsity level');
%         ylabel('Error of sparse pattern recovery (%)');
%         
        hfig23 = figure;  idx_sparse = 1; idx_trial = 1; idx_hard = [2 3];
        subplot(4,1,1);
        plot(sol_opt{idx_trial,idx_sparse});
        ylabel('Original'); axis tight;
        subplot(4,1,2);
        plot(sol_OMP{idx_trial,idx_sparse}); 
        ylabel('OMP'); axis tight; 
        subplot(4,1,3);
        plot(sol_CS_ad{idx_trial,idx_sparse}(:,idx_hard(1),idx_rho_sel));
        ylabel(sprintf('ADMM, var = %d%%',var_hardware_vec(idx_hard(1)))); axis tight;
        subplot(4,1,4);
        plot(sol_CS_ad{idx_trial,idx_sparse}(:,idx_hard(2),idx_rho_sel));
        ylabel(sprintf('ADMM, var = %d%%',var_hardware_vec(idx_hard(2)))); axis tight;
        

    end
 
end