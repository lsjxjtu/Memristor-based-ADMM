function [U] = Gram_Schmidt(A)
    [m,n] = size(A);
    Q = zeros(m,n);
    R = zeros(n,n);
    U = Q;
    for j = 1:n
        v = A(:,j);
        for i = 1:(j-1)
            R(i,j) = Q(:,i).'*A(:,j);
%             v = v - R(i,j)*Q(:,i);
            v = v - R(i,j)*Q(:,i)/(Q(:,i).'*Q(:,i));
        end
%         R(j,j) = norm(v);
%         Q(:,j) = v/R(j,j);
        Q(:,j) = v;
        U(:,j) = v/norm(v);
    end
    
end