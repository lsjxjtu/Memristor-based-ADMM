function [ lam_est, V_est,iter_PI,error_lam ] =   PI_generalized_decomp(A, k, options)

    V_est = []; lam_est = [];
    
    [V,D] = eig(A); eig_A = diag(D);
    [~,idx_eigA] = sort(abs(diag(D)),'descend');
    eig_A = eig_A(idx_eigA(1:k));  
    V = V(:,idx_eigA(1:k));
    iter_PI = 0;
    while 1
        
         [lam_est_temp, V_est_temp,~,iter_PI_temp,~] = PI_generalized(A, options);
         
         V_est = [V_est,V_est_temp]; iter_PI = iter_PI + iter_PI_temp;
         lam_est = [lam_est;lam_est_temp.'];
         A = A - V_est_temp*diag(lam_est_temp)*V_est_temp.';
         
         if size(V_est,2) >= k
             break;
         end
         
    end
    
    unitary_test = V_est.'*V_est;
    
    if norm(unitary_test-eye(size(unitary_test,1)),'fro') > 1e-1
        error('invalid orthogonality!')
    end
    
    error_lam = norm(lam_est(1:k)-eig_A);

end