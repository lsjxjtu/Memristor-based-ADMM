function G_var = HardwareVarNoise(G, per)

    G_noise = randn(size(G,1), size(G,2));
    G_noise(find(G==0)) = 0; %G_noise = G_noise - diag(diag(G_noise));
    G_noise = G_noise*( per * norm(G,'fro')/ norm(G_noise,'fro') );

    G_var = G + G_noise;

end